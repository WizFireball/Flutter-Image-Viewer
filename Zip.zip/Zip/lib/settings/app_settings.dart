import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// User-adjustable UI sizes. Changes notify listeners instantly;
/// call [save] to persist them (the settings page does this on slider release).
class AppSettings extends ChangeNotifier {
  static const defaultPillTextSize = 14.0;
  static const defaultPillIconSize = 24.0;
  static const defaultPillBgOpacaity = 0.4;
  static const defaultArrowIconSize = 28.0;
  static const defaultTooltipTextSize = 12.0;


  double _pillTextSize = defaultPillTextSize;
  double _pillIconSize = defaultPillIconSize;
  double _pillBgOpacity = defaultPillBgOpacaity;

  double _arrowIconSize = defaultArrowIconSize;
  double _tooltipTextSize = defaultTooltipTextSize;
  

  double get pillTextSize => _pillTextSize;
  double get pillIconSize => _pillIconSize;
  double get arrowIconSize => _arrowIconSize;
  double get tooltipTextSize => _tooltipTextSize;

  /// Arrow button grows with its icon.
  double get arrowButtonSize => _arrowIconSize + 20;

  set pillTextSize(double v) {
    _pillTextSize = v;
    notifyListeners();
  }

  set pillIconSize(double v) {
    _pillIconSize = v;
    notifyListeners();
  }

  set arrowIconSize(double v) {
    _arrowIconSize = v;
    notifyListeners();
  }

  set tooltipTextSize(double v) {
    _tooltipTextSize = v;
    notifyListeners();
  }



  double get pillBgOpacity => _pillBgOpacity;

  set pillBgOpacity(double v) {
    _pillBgOpacity = v.clamp(0.0, 1.0);
    notifyListeners();
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      _pillTextSize = p.getDouble('pillTextSize') ?? defaultPillTextSize;
      _pillIconSize = p.getDouble('pillIconSize') ?? defaultPillIconSize;
      _arrowIconSize = p.getDouble('arrowIconSize') ?? defaultArrowIconSize;
      _tooltipTextSize = p.getDouble('tooltipTextSize') ?? defaultTooltipTextSize;

      _pillBgOpacity = p.getDouble('pillBgOpacity') ?? defaultPillBgOpacaity;

      notifyListeners();
    } catch (_) {
      // fall back to defaultaults
    }
  }

  Future<void> save() async {
    try {

      // Internally they all calling setState() when
      // Listner is notified

      final p = await SharedPreferences.getInstance();
      await p.setDouble('pillTextSize', _pillTextSize);
      await p.setDouble('pillIconSize', _pillIconSize);
      await p.setDouble("pillBgOpacity", _pillBgOpacity);


      await p.setDouble('arrowIconSize', _arrowIconSize);
      await p.setDouble('tooltipTextSize', _tooltipTextSize);

    } catch (_) {} // do nothing lol
  }

  Future<void> reset() async {
    _pillTextSize = defaultPillTextSize;
    _pillIconSize = defaultPillIconSize;
    _pillBgOpacity = defaultPillBgOpacaity;

    _arrowIconSize = defaultArrowIconSize;
    _tooltipTextSize = defaultTooltipTextSize;
  
    notifyListeners();
    await save();
  }
}

/// App-wide instance (loaded in main()).
final appSettings = AppSettings();

// An instance inside this file so that i dont
// create mutiple instance by mistake in multiple files
