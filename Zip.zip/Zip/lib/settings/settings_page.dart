// NOTE FIX THE ISSUE WITH SLIDER OF OPACITY
// IF FIXED REMOVE THIS COMMENTs

import 'package:flutter/material.dart';
import 'package:image_app1/settings/app_settings.dart';
import 'package:image_app1/widgets/control_pill.dart';
import 'package:image_app1/widgets/nav_arrow_button.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.transparent,
        actions: [
          TextButton.icon(
            onPressed: appSettings.reset,
            icon: const Icon(Icons.restart_alt_rounded),
            label: const Text('Reset to defaults'),
          ),
          const SizedBox(width: 8),
        ],
      ),

      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: ListenableBuilder(
            listenable: appSettings,
            builder: (context, _) => ListView(
              // L = left , t = top , r = right , b = bottom
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
              children: [
                _preview(context),
                const SizedBox(height: 28),
                _section(context, 'Toolbar'),

                _SizeSlider(
                  label: 'Text size',
                  value: appSettings.pillTextSize,
                  min: 10,
                  max: 28,
                  onChanged: (v) => appSettings.pillTextSize = v,
                ),

                _SizeSlider(
                  label: 'Icon size',
                  value: appSettings.pillIconSize,
                  min: 16,
                  max: 48,
                  onChanged: (v) => appSettings.pillIconSize = v,
                ),

                // _SizeSlider(
                // 
                //   // NOTE FIX THE ISSUE WITH SLIDER OF OPACITY
                //   // IF FIXED REMOVE THIS COMMENT
                // 
                //   label: 'ToolBar Background Opacity',
                //   value: appSettings.pillBgOpacity,
                //   min: 0,
                //   max: 1,
                //   onChanged: (v) => appSettings.pillBgOpacity = v,
                // ),

                // [FIXED]
                _SizeSlider(
                  label: 'Opacity',
                  value: appSettings.pillBgOpacity,
                  min: 0,
                  max: 1,
                  divisions: 100,
                  display: (v) => '${(v * 100).round()}%',
                  onChanged: (v) => appSettings.pillBgOpacity = v,
                ),


                const SizedBox(height: 16),
                _section(context, 'Arrow buttons'),
                _SizeSlider(
                  label: 'Arrow icon size',
                  value: appSettings.arrowIconSize,
                  min: 16,
                  max: 64,
                  onChanged: (v) => appSettings.arrowIconSize = v,
                ),


                const SizedBox(height: 16),
                _section(context, 'Tooltips'),
                _SizeSlider(
                  label: 'Tooltip text size',
                  value: appSettings.tooltipTextSize,
                  min: 10,
                  max: 24,
                  onChanged: (v) => appSettings.tooltipTextSize = v,
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _section(BuildContext context, String title) => Padding(
    padding: const EdgeInsets.only(bottom: 4),
    child: Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 24)
    ),
  );

  // Preview sits on a bright background on purpose, so you can check
  // readability in the worst case.
  Widget _preview(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
      decoration: BoxDecoration(
        // color: Colors.lightBlueAccent,
        borderRadius: BorderRadius.circular(16),
        // gradient: const LinearGradient(
        //   // colors: [Color(0xFFF4F4F4), Color(0xFFCFE3FF)],
        //   colors: [Color.fromARGB(255, 193, 241, 117), Color.fromARGB(255, 151, 191, 248)],
        //   begin: Alignment.topLeft,
        //   end: Alignment.bottomRight,
        // ),

        // [Update] : Changed bg Gradient to Image so that pill
        //            frosted glass filter is visible
        image: DecorationImage(
          image: AssetImage("assets/strip.png"),
          fit: BoxFit.cover
          
        )

      ),
      child: Column(
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,

            // A placeHolder ControlPill with no functionality
            child: ControlPill(
              label: '3 / 24',
              fileName: 'placeholder_photo.jpg',
              isFullScreen: false,

              // these are place holder so they do nothing
              onOpen: () {},
              onRotate: () {},
              onFullscreen: () {},
              onSettings: () {},
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              NavArrowButton(
                onPressed: () {},
                icon: Icons.chevron_left_rounded,
              ),
              const SizedBox(width: 12),
              NavArrowButton(
                onPressed: () {},
                icon: Icons.chevron_right_rounded,
              ),
              const SizedBox(width: 32),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'Tooltip sample',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: appSettings.tooltipTextSize,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SizeSlider extends StatelessWidget {
  final String label;
  final double value, min, max;

  final int? divisions;
  final String Function(double)? display;
  final ValueChanged<double> onChanged;

  const _SizeSlider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,

    this.divisions,
    this.display
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 140,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 16
            ),
          )
        ),
        Expanded(
          child: Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            divisions: divisions ?? (max - min).round(),
            onChanged: onChanged,
            onChangeEnd: (_) => appSettings.save(),
          ),
        ),
        SizedBox(
          width: 56,
          child: Text(
            display?.call(value) ?? '${value.round()} px'
            ,textAlign: TextAlign.end,
            style: TextStyle(
              fontSize: 18
            ),
          ),
        ),
      ],
    );
  }
}
