import 'dart:io';
import 'package:flutter/services.dart';
import 'package:image_app1/widgets/nav_arrow_button.dart';
import 'package:image_app1/widgets/top_nav_bar.dart';
import 'package:path/path.dart' as path;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

class ImageViewer extends StatefulWidget {
  const ImageViewer({super.key});

  @override
  State<ImageViewer> createState() => _ImageViewerState();
}

class _ImageViewerState extends State<ImageViewer> {
  // list of images
  List<String> images = [];
  int currentIndex = 0;

  // fullscreen
  bool isFullScreen = false;

  // rotated  0  = 0 deg
  // each number increase means 90deg clock wise rotation
  int rotationCounter = 0;

  // For keyBoard Listner
  final focusNode = FocusNode();

  Future<void> pickImages() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false, // pick just ONE image
    );

    if (result != null && result.files.single.path != null) {
      // ! telling that is not null

      String pickedFile = result.files.single.path!;

      // get the folder of that image
      String folder = path.dirname(pickedFile);

      // get all files in that folder
      Directory dir = Directory(folder);
      List<FileSystemEntity> allFiles = dir.listSync();

      // keep only image files
      List<String> imageExtensions = [
        '.jpg',
        '.jpeg',
        '.png',
        '.gif',
        '.bmp',
        '.webp',
      ];
      List<String> foundImages = [];

      for (var file in allFiles) {
        String ext = path.extension(file.path).toLowerCase();
        if (imageExtensions.contains(ext)) {
          foundImages.add(file.path);
        }
      }

      // sort them alphabetically
      foundImages.sort();

      // find where the picked image is in the list
      int startIndex = foundImages.indexOf(pickedFile);

      setState(() {
        images = foundImages;
        currentIndex = startIndex;
      });
    }
  }

  void goToNext() {
    setState(() {
      if (currentIndex < images.length - 1) {
        if(rotationCounter !=0){
          rotationCounter = 0;
        }
        currentIndex++;
      }
    });
  }

  void goToPrevious() {
    setState(() {
      if (currentIndex > 0) {
        if(rotationCounter !=0){
          rotationCounter = 0;
        }
        currentIndex--;
      }
    });
  }

  // rotate the widget so that it feels like its rotating
  Future<void> rotateImage() async {
    setState(() {
      if (rotationCounter == 3) {
        rotationCounter = 0;
      } else {
        rotationCounter++;
      }
    });
  }

  // toggle FullScreen
  void toggleFullScreen() async {
  if (isFullScreen) {
    await windowManager.setFullScreen(false);
    await windowManager.setTitleBarStyle(TitleBarStyle.normal);
    setState(() => isFullScreen = false);
  } else {
    await windowManager.setFullScreen(true);
    await windowManager.setTitleBarStyle(TitleBarStyle.hidden);
    setState(() => isFullScreen = true);
  }
}

  // empty state (no images yet)
  Widget _buildEmptyState() {
    return Row(
      children: [
        ElevatedButton(
          onPressed: pickImages,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueAccent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0),
            ),
            foregroundColor: Colors.black,
          ),

          child: Row(
            children: [
              const Text(
                "Pick Image",
                style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 236, 236, 236),
                ),
              ),

              const SizedBox(width: 5),

              const Icon(
                Icons.image,
                color: Color.fromARGB(255, 236, 236, 236),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // show the image
  Widget _buildImageView() {
    // return Center(
    //   child: Image.file(
    //     File(images[currentIndex]),
    //     fit: BoxFit.contain,
    //   ),
    // );

    return Stack(
      children: [
        // if fullscreen is enables donot show open image menu
        if (!isFullScreen)
          Padding(
            padding: EdgeInsets.only(
              top: isFullScreen ? 0 : 20, 
              bottom: isFullScreen ? 0 : 10
            ),
            child: TopNavBar(
              pickImages: pickImages,
              rotateFuntion: rotateImage,
            ),
          ),

        Padding(
          padding: EdgeInsetsGeometry.only(
            top: isFullScreen ? 0 : 60,
            bottom: isFullScreen ? 0 : 10,
          ),
          child: Center(
            child: RotatedBox(
              quarterTurns: rotationCounter, // initially 0
              child: Image.file(
                File(images[currentIndex]),
                fit: BoxFit.contain,
                width: double.infinity,
                height: double.infinity,
              ),
            ),
          ),
        ),

        // left arrow
        Positioned(
          left: 16,
          top: 0,
          bottom: 0,
          child: Center(
            // custon navButton present in Widgets folder
            child: NavArrowButton(
              onPressed: goToPrevious,
              icon: Icons.chevron_left_outlined,
            ),
          ),
        ),

        // right arrow button
        Positioned(
          right: 16,
          top: 0,
          bottom: 0,
          child: Center(
            // custon navButton present in Widgets folder
            child: NavArrowButton(
              onPressed: goToNext,
              icon: Icons.chevron_right_outlined,
            ),
          ),
        ),

        Positioned(
          bottom: 4,
          right: 4,

          child: IconButton(
            iconSize: 30,
            color: Colors.white,
            onPressed: toggleFullScreen,

            // onPressed: rotateImage, // just used to test rotate funtion
            tooltip: isFullScreen ? "Exit Fullscreen (F)" : "Fullscreen (F)",

            // if not fullscreen show exit full screen icon
            // if not fullscreen show full screen icon
            icon: Icon(isFullScreen ? Icons.fullscreen_exit : Icons.fullscreen),
          ),
        ),
      ],
    );
  }

  // draws the screen MAIN BUILD
  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   backgroundColor: Colors.black,
    //   body: images.isEmpty ? _buildEmptyState() : _buildImageView(),
    // );
    // 👆 old , dont remove it idiot
    // it can be used for future testing

    return KeyboardListener(
      focusNode: focusNode,

      // Automatically start listen to user clicking anything
      autofocus: true,

      // This takes a funtion to listen on a certain key event
      onKeyEvent: (KeyEvent event) {
        // if event is you pressed a key
        if (event is KeyDownEvent) {
          // if you presse a left arror key
          if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
            // then call this funtion
            goToPrevious(); // move to previous image
          } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
            // then call this funtion
            goToNext();
          }

          // for full screen
          else if(event.logicalKey ==LogicalKeyboardKey.keyF){
            toggleFullScreen();
          }

          // for rotate shortcut ctrl+R
          // new thing hardware key
          else if (HardwareKeyboard.instance.isControlPressed &&
              event.logicalKey == LogicalKeyboardKey.keyR) {
            rotateImage();
          }
        }
      },

      // ==================================================
      // ==================================================
      //            MAIN BODY
      // ==================================================
      // ==================================================
      child: Scaffold(
        backgroundColor: Colors.transparent,
        // OLD STYLE
        body: images.isEmpty ? _buildEmptyState() : _buildImageView(),
      ),
    );
  }
}
