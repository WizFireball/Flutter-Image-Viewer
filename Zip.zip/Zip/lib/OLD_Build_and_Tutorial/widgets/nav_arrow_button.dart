import 'package:flutter/material.dart';

class NavArrowButton extends StatelessWidget {

  // varibles it required
  final VoidCallback onPressed;
  final IconData icon;


  // constructor
  const NavArrowButton({
    super.key,
    required this.onPressed,
    required this.icon
  });



  @override
  Widget build(BuildContext context) {
    return  ElevatedButton(

      style: ElevatedButton.styleFrom(

        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10)
        ),

        // width,height
        fixedSize: Size(80,50),
        iconSize: 30,

        backgroundColor: const Color.fromARGB(12, 255, 255, 255),
        iconColor: Colors.white,
        foregroundColor: Colors.white,



      ),

      onPressed: onPressed,
      child: Icon(icon),

      

    );
  }
}