import 'package:flutter/material.dart';

class TopNavBar extends StatelessWidget {

  // Present in image_viewer.dart file 
  // a funtion which present to pick image
  final VoidCallback pickImages;
  final VoidCallback rotateFuntion;

  const TopNavBar({
    super.key,
    required this.pickImages,
    required this.rotateFuntion
  });

  @override
  Widget build(BuildContext context){
    return Row(

      mainAxisAlignment: MainAxisAlignment.spaceBetween,

      children: [
        ElevatedButton(
          onPressed: pickImages,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueAccent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0),
            ),
            foregroundColor: Colors.black,
          ),

          child: Row(
            children: [
              const Text(
                "Pick Image",
                style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 236, 236, 236),
                ),
              ),

              const SizedBox(width: 5),

              const Icon(
                Icons.image,
                color: Color.fromARGB(255, 236, 236, 236),
              ),
            ],
          ),
        ),


        Padding(
          padding: const EdgeInsets.only(
            right: 10
          ),
          child: IconButton(
          
            color: Colors.white,
            splashColor: Colors.white,
            tooltip: "Rotate (Ctrl+R)",
          
            onPressed: rotateFuntion,
            icon: Icon(Icons.rotate_right_outlined)
          ),
        )


      ],
    );
  }
}