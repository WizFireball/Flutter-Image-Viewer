import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:image_app1/settings/app_settings.dart';

/// Dark floating toolbar: open, counter + filename, rotate, fullscreen, settings.
class ControlPill extends StatelessWidget {
  final String label; // e.g. "3 / 24"
  final String fileName;
  final bool isFullScreen;
  final VoidCallback onOpen;
  final VoidCallback onRotate;
  final VoidCallback onFullscreen;
  final VoidCallback onSettings;

  const ControlPill({
    super.key,
    required this.label,
    required this.fileName,
    required this.isFullScreen,
    required this.onOpen,
    required this.onRotate,
    required this.onFullscreen,
    required this.onSettings,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) {

        final text = appSettings.pillTextSize;
        final opacity = appSettings.pillBgOpacity;

        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            boxShadow: [
              BoxShadow(

                // shadow 
                color: Colors.black.withValues(alpha: 0.45 * opacity),
                blurRadius: 24,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: BackdropFilter(

              // Image Filter is costly only add filter if its on in settings
              // disable it when opacity is 0 and 1
              // disable it when it is disabled in setting
              filter:ImageFilter.blur(sigmaX: 24*opacity, sigmaY: 24*opacity)
              
              
              ,


              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF161616).withValues(alpha: opacity),
                  borderRadius: BorderRadius.circular(999),
                  border:
                      Border.all(color: Colors.white.withValues(alpha: 0.14*opacity)),
                ),
                child: IconButtonTheme(
                  data: IconButtonThemeData(
                    style: IconButton.styleFrom(
                      foregroundColor: Colors.white,
                      iconSize: appSettings.pillIconSize,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'Open image',
                        onPressed: onOpen,
                        icon: const Icon(Icons.folder_open_rounded),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              label,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: text,
                                fontWeight: FontWeight.w600,
                                fontFeatures: const [
                                  FontFeature.tabularFigures()
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 220),
                              child: Text(
                                fileName,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: text - 1,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Rotate (Ctrl+R)',
                        onPressed: onRotate,
                        icon: const Icon(Icons.rotate_right_rounded),
                      ),
                      IconButton(
                        tooltip: isFullScreen
                            ? 'Exit fullscreen (F)'
                            : 'Fullscreen (F)',
                        onPressed: onFullscreen,
                        icon: Icon(isFullScreen
                            ? Icons.fullscreen_exit_rounded
                            : Icons.fullscreen_rounded),
                      ),
                      IconButton(
                        tooltip: 'Settings (Ctrl+,)',
                        onPressed: onSettings,
                        icon: const Icon(Icons.tune_rounded),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
