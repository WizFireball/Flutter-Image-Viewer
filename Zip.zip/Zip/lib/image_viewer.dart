import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as path;
import 'package:window_manager/window_manager.dart';
import 'package:image_app1/settings/settings_page.dart';
import 'package:image_app1/widgets/control_pill.dart';
import 'package:image_app1/widgets/nav_arrow_button.dart';

class ImageViewer extends StatefulWidget {
  const ImageViewer({super.key});

  @override
  State<ImageViewer> createState() => _ImageViewerState();
}

class _ImageViewerState extends State<ImageViewer> {
  List<String> images = [];
  int currentIndex = 0;

  bool isFullScreen = false;

  // each increase = 90deg clockwise
  int rotationCounter = 0;

  // controls fade out after a short idle
  bool showControls = true;
  bool _hoveringControls = false; // pointer is on a button / the pill
  Timer? _hideTimer;

  final focusNode = FocusNode();

  @override
  void dispose(){
    _hideTimer?.cancel();
    focusNode.dispose();
    super.dispose();
  }

  void _wakeControls(){
    if (!showControls) setState(() => showControls = true);
    _restartHideTimer();
  }

  void _restartHideTimer(){
    _hideTimer?.cancel();

    // mouse pointer is on a control: stay visible
    if (_hoveringControls) return; 

    _hideTimer = Timer(const Duration(seconds: 2), () {

      // 2 second time is passed : 
      // 
      // (mounted) if this widget still exist in tree
      // AND 
      // mouse pointer not pointing the arrow button or the pill
      // 
      // set showControls visiblity to false
      // so they disapper
      if(mounted && !_hoveringControls) setState(() => showControls = false);
    });
  }

  /// Wrap any control so the bar stays up while the pointer is on it.
  Widget _keepAlive(Widget child){
    return MouseRegion(
      onEnter: (_) {
        _hoveringControls = true;
        _hideTimer?.cancel();
      },
      onHover: (_) {
        _hoveringControls = true;
        _hideTimer?.cancel();
      },
      onExit: (_) {
        _hoveringControls = false;
        _restartHideTimer();
      },
      child: child,
    );
  }

  Future<void> pickImages() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false, 
      // pick single file at the time of
      // initial image selection
    );

    // if you picked no file or pressed cancel on native file picker
    // do nothing
    if (result == null || result.files.single.path == null) return;


    final pickedFile = result.files.single.path!;
    final folder = path.dirname(pickedFile);

    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];

    // fetch all images names in that folder matching with above present extension
    // it fetch the names and store their path with file name

    // It does not load all images present in that folder into memory
    // it just fetch all path of all images in that folder
    final foundImages = Directory(folder)
        .listSync()
        .map((f) => f.path)
        .where((p) => imageExtensions.contains(path.extension(p).toLowerCase()))
        .toList()
      ..sort();

    // start from that image which you picked
    final startIndex = foundImages.indexOf(pickedFile);

    setState(() {
      images = foundImages;
      currentIndex = startIndex < 0 ? 0 : startIndex;
      rotationCounter = 0;
    });
    _hoveringControls = false; // the file dialog may have swallowed onExit
    _wakeControls();
  }

  void goToNext() {
    if (currentIndex < images.length - 1) {
      setState(() {
        rotationCounter = 0;
        currentIndex++;
      });
    }
  }

  void goToPrevious() {
    if (currentIndex > 0) {
      setState(() {
        rotationCounter = 0;
        currentIndex--;
      });
    }
  }

  void rotateImage() {
    setState(() => rotationCounter = (rotationCounter + 1) % 4);
  }

  Future<void> toggleFullScreen() async {
    if (isFullScreen) {
      await windowManager.setFullScreen(false);
      await windowManager.setTitleBarStyle(TitleBarStyle.normal);
    } else {
      await windowManager.setFullScreen(true);
      await windowManager.setTitleBarStyle(TitleBarStyle.hidden);
    }
    setState(() => isFullScreen = !isFullScreen);
  }

  Future<void> openSettings() async {
    _hoveringControls = false; // the new page may swallow onExit
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SettingsPage()),
    );
    focusNode.requestFocus(); // restore keyboard shortcuts
    if (images.isNotEmpty) _wakeControls();
  }

  // ── Empty state ─────────────────────────────────────────────
  Widget _buildEmptyState() {
    return Stack(
      children: [
        _emptyContent(),
        Positioned(
          top: 12,
          right: 12,
          child: IconButton(
            tooltip: 'Settings (Ctrl+,)',
            onPressed: openSettings,
            icon: const Icon(Icons.tune_rounded),
          ),
        ),
      ],
    );
  }

  Widget _emptyContent() {

    // cs means colorScheme
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: cs.primary.withValues(alpha: 0.12),
            ),
            child: Icon(Icons.photo_library_outlined,
                size: 48, color: cs.primary),
          ),
          const SizedBox(height: 24),
          Text('Open an image',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 40)
              
          ),
          const SizedBox(height: 8),
          const Text(
            'Pick a photo to browse everything in its folder',
            style: TextStyle(color: Colors.white54,fontSize: 18),
          ),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: pickImages,
            icon: const Icon(Icons.folder_open_rounded),
            label: const Text('Choose image'),
            style: FilledButton.styleFrom(
              shape: const StadiumBorder(),
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            '<- -> to browse   ·   F fullscreen   ·   Ctrl+R rotate   ·   Ctrl+, settings',
            style: TextStyle(color: Colors.white30, fontSize: 16),
          ),
        ],
      ),
    );
  }

  // ── Image view ──────────────────────────────────────────────
  Widget _buildImageView() {
    final current = images[currentIndex];

    return MouseRegion(
      onHover: (_) => _wakeControls(),
      child: Stack(
        children: [
          // Zoomable image, cross-fades between photos
          Positioned.fill(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: InteractiveViewer(
                key: ValueKey(current),
                minScale: 1,
                maxScale: 6,
                child: Center(
                  child: RotatedBox(
                    quarterTurns: rotationCounter,
                    child: Image.file(
                      File(current),
                      fit: BoxFit.contain,
                      gaplessPlayback: true,
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ================== CONTROLS =====================

          // Controls fade out when idle (but never while hovered)
          Positioned.fill(
            child: IgnorePointer(
              ignoring: !showControls,
              child: AnimatedOpacity(
                opacity: showControls ? 1 : 0,
                duration: const Duration(milliseconds: 250),
                child: Stack(
                  children: [
                    Positioned(
                      left: 16,
                      top: 0,
                      bottom: 0,
                      child: Center(
                        child: _keepAlive(
                          NavArrowButton(
                            onPressed: goToPrevious,
                            icon: Icons.chevron_left_rounded,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 16,
                      top: 0,
                      bottom: 0,
                      child: Center(
                        child: _keepAlive(
                          NavArrowButton(
                            onPressed: goToNext,
                            icon: Icons.chevron_right_rounded,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 24,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: _keepAlive(
                          ControlPill(
                            label: '${currentIndex + 1} / ${images.length}',
                            fileName: path.basename(current),
                            isFullScreen: isFullScreen,
                            onOpen: pickImages,
                            onRotate: rotateImage,
                            onFullscreen: toggleFullScreen,
                            onSettings: openSettings,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }



  // THE MAIN BUILD FUNCTION


  @override
  Widget build(BuildContext context) {
    return KeyboardListener(
      focusNode: focusNode,
      autofocus: true,
      onKeyEvent: (KeyEvent event) {
        if (event is! KeyDownEvent) return;

        if (event.logicalKey == LogicalKeyboardKey.arrowLeft){
          goToPrevious();
        } else if (event.logicalKey == LogicalKeyboardKey.arrowRight){
          goToNext();
        } else if (event.logicalKey == LogicalKeyboardKey.keyF){
          toggleFullScreen();
        } else if (HardwareKeyboard.instance.isControlPressed &&
            event.logicalKey == LogicalKeyboardKey.keyR){
          rotateImage();
        } else if (HardwareKeyboard.instance.isControlPressed &&
            event.logicalKey == LogicalKeyboardKey.comma){
          openSettings();
        }
        if (images.isNotEmpty) _wakeControls();
      },
      child: Scaffold(
        body: images.isEmpty ? _buildEmptyState() : _buildImageView(),
      ),
    );
  }
}