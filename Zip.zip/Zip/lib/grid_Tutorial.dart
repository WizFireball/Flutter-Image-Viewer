// [Notice] : Remove this file this file is just used for
// testing grid layout and has no role other than testing this that
// stuff so remove this file before puting this on github
// 
// If you still uploaded so just a remainder this file has
// nothing to do with whole project its just used for testing.


import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';
// import 'package:image_app1/_main.dart';

void main() async{

  WidgetsFlutterBinding.ensureInitialized();
  // Must add this line.
  await windowManager.ensureInitialized();

  WindowOptions windowOptions = WindowOptions(
    size: Size(800, 600),
    center: true,
    backgroundColor: Colors.transparent,
    skipTaskbar: false,
    titleBarStyle: TitleBarStyle.normal,
  );
  windowManager.waitUntilReadyToShow(windowOptions, () async {
    await windowManager.show();
    await windowManager.focus();
  });


  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Grid",

      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Color.fromARGB(255, 28, 28, 28),

      // Grid View
      // Three main options
      // 1. count   = when you want fized no. of columns on each screen size
      // 2. extent  = 
      // 3. builder

      // CrossAxis is no. of columns

      body: Padding(
        padding: const EdgeInsets.all(20.0),


        // ⭐ .count()

        // child: GridView.count(
        //   crossAxisCount: 4 ,
        //   crossAxisSpacing: 10, // column spacing between each column
        //   mainAxisSpacing: 10, // spacing between each row
          
        //   children: [
        //     Container(color: Colors.redAccent,),
        //     Container(color: Colors.orangeAccent),
        //     Container(color: Colors.amber,),
        //     Container(color: Colors.lightGreenAccent,),
        //     Container(color: Colors.blueAccent,),
        //     Container(color: Colors.purpleAccent,),
            
        //   ],  



        // // ⭐ .extent()

        child: GridView.extent(
          maxCrossAxisExtent: 200,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          // if 200 not then shift to next row
          // resize the window to see the effect

          children: [
            Container(color: Colors.redAccent,),
            Container(color: Colors.orangeAccent),
            Container(color: Colors.amber,),
            Container(color: Colors.lightGreenAccent,),
            Container(color: Colors.blueAccent,),
            Container(color: Colors.purpleAccent,),
          ], 
        
        ),


        // ⭐ .builder()
        // This is used when the data is varibale like in
        // playstore the grid view is same but the cell are varibales
        // as you scroll down you get more cells
        // as well as in youtube there is no constant no. of cells in
        // grind in youtube they are varibale

        // to achive this we use .builder in gridview

        // child: GridView.builder(
        //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: crossAxisCount),
        //   itemBuilder: itemBuilder



        // ),

      )

      
    );
  }
}


